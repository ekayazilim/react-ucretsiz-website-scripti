<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// PHPMailer kütüphanesini yükle
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/Exception.php';
require 'PHPMailer/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    $mail = new PHPMailer(true);

    try {
        // SMTP Ayarları
        $mail->isSMTP();
        $mail->Host = 'mail.ekasunucu.org'; // SMTP Sunucusu
        $mail->SMTPAuth = true;
        $mail->Username = 'info@ekabilisim.com'; // SMTP Kullanıcı Adı
        $mail->Password = 'ym?0+$+0}F+M'; // SMTP Şifresi
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Güvenli bağlantı
        $mail->Port = 587; // SMTP Portu

        // Gönderen ve Alıcı Bilgileri
        $mail->setFrom('info@ekabilisim.com', 'EKA İletişim'); // Gönderen
        $mail->addAddress('ekasunucu@gmail.com', 'EKA Kullanıcı'); // Alıcı
        $mail->addReplyTo($email, $name); // Cevap adresi

        // İçerik
        $mail->isHTML(true);
        $mail->Subject = 'Yeni İletişim Mesajı';
        $mail->Body    = "
            <h3>Yeni Mesaj Geldi</h3>
            <p><strong>Ad:</strong> {$name}</p>
            <p><strong>E-posta:</strong> {$email}</p>
            <p><strong>Mesaj:</strong><br>{$message}</p>
        ";
        $mail->AltBody = "Ad: {$name}\nE-posta: {$email}\nMesaj:\n{$message}";

        $mail->send();
        echo json_encode(["status" => "success", "message" => "Mesaj başarıyla gönderildi."]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "Mesaj gönderilemedi. Hata: {$mail->ErrorInfo}"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Geçersiz istek."]);
}
