import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faFacebookF,
  faTwitter,
  faLinkedinIn,
  faInstagram,
  faYoutube,
} from '@fortawesome/free-brands-svg-icons';

const SocialLinks = () => {
  const socials = [
    {
      icon: faFacebookF,
      href: "https://www.facebook.com/ekayazilim",
      label: "Facebook",
    },
    {
      icon: faTwitter,
      href: "https://twitter.com/ekayazilim",
      label: "Twitter",
    },
    {
      icon: faLinkedinIn,
      href: "https://www.linkedin.com/company/eka-software-limited/",
      label: "LinkedIn",
    },
    {
      icon: faInstagram,
      href: "https://www.instagram.com/ekayazilim.com.tr/",
      label: "Instagram",
    },
    {
      icon: faYoutube,
      href: "https://www.youtube.com/@ekayazilim",
      label: "YouTube",
    },
  ];

  return (
    <div className="flex space-x-4">
      {socials.map((social) => (
        <a
          key={social.label}
          href={social.href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-muted-foreground hover:text-primary transition-colors"
          aria-label={social.label}
        >
          <FontAwesomeIcon icon={social.icon} className="w-6 h-6" />
        </a>
      ))}
    </div>
  );
};

export default SocialLinks;