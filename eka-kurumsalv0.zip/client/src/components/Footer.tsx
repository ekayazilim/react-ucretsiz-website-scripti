import { Link } from "wouter";
import SocialLinks from "./SocialLinks";
import { MapPin, Phone, Mail } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-muted/20 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">EKA Yazılım</h3>
            <p className="text-muted-foreground">
              Modern teknolojilerle geleceğin yazılım çözümleri
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Hızlı Erişim</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-muted-foreground hover:text-primary cursor-pointer">
                    Ana Sayfa
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="text-muted-foreground hover:text-primary cursor-pointer">
                    Hakkımızda
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/services">
                  <span className="text-muted-foreground hover:text-primary cursor-pointer">
                    Hizmetler
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="text-muted-foreground hover:text-primary cursor-pointer">
                    İletişim
                  </span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">İletişim</h3>
            <ul className="space-y-4">
              <li className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span className="text-muted-foreground">0 (850) 307 34 58</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <a
                  href="mailto:info@ekayazilim.com.tr"
                  className="text-muted-foreground hover:text-primary"
                >
                  info@ekayazilim.com.tr
                </a>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                <span className="text-muted-foreground">
                  Halkalı Merkez, Fatih Cd. özgür apartmanı no 45 iç kapı no: 3,
                  34303 Küçükçekmece/İSTANBUL
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Sosyal Medya</h3>
            <SocialLinks />
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} EKA Yazılım. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
