import { Canvas } from "@react-three/fiber";
import { OrbitControls, Sphere } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import type { Mesh } from "three";

const AnimatedSphere = () => {
  const sphereRef = useRef<Mesh>(null);

  useFrame(({ clock }) => {
    if (sphereRef.current) {
      sphereRef.current.rotation.x = clock.getElapsedTime() * 0.5;
      sphereRef.current.rotation.y = clock.getElapsedTime() * 0.3;
    }
  });

  return (
    <Sphere ref={sphereRef} args={[1, 32, 32]}>
      <meshStandardMaterial
        color="#0066ff"
        wireframe
        roughness={0.5}
        metalness={0.8}
      />
    </Sphere>
  );
};

const Hero3D = () => {
  return (
    <div className="h-screen w-full relative">
      <Canvas
        camera={{ position: [0, 0, 5] }}
        className="bg-transparent"
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <AnimatedSphere />
        <OrbitControls enableZoom={false} />
      </Canvas>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center z-10">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          Geleceğin Yazılım Çözümleri
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground">
          Modern teknolojilerle işinizi ileriye taşıyoruz
        </p>
      </div>
    </div>
  );
};

export default Hero3D;