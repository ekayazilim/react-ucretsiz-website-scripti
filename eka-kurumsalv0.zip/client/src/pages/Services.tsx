import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Code,
  Smartphone,
  Globe,
  Database,
  Cloud,
  LineChart,
} from "lucide-react";

const Services = () => {
  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-6">Hizmetlerimiz</h1>
            <p className="text-xl text-muted-foreground mb-12">
              Modern teknolojilerle işletmenizi geleceğe taşıyoruz
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <service.icon className="w-8 h-8 text-primary" />
                    <h3 className="text-xl font-semibold">{service.title}</h3>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/contact">
              <Button size="lg">Teklif Alın</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

const services = [
  {
    icon: Code,
    title: "Yazılım Geliştirme",
    description: "Modern teknolojilerle özel yazılım çözümleri",
    features: [
      "Web Uygulamaları",
      "Masaüstü Yazılımlar",
      "API Geliştirme",
      "Sistem Entegrasyonları",
    ],
  },
  {
    icon: Smartphone,
    title: "Mobil Uygulama",
    description: "iOS ve Android için native uygulamalar",
    features: [
      "Cross-platform Geliştirme",
      "UI/UX Tasarım",
      "Push Bildirimler",
      "Offline Çalışma",
    ],
  },
  {
    icon: Globe,
    title: "Web Tasarım",
    description: "Kurumsal ve e-ticaret web siteleri",
    features: [
      "Responsive Tasarım",
      "SEO Optimizasyonu",
      "Hızlı Yükleme",
      "Güvenlik",
    ],
  },
  {
    icon: Database,
    title: "Veritabanı Çözümleri",
    description: "Veritabanı tasarım ve yönetimi",
    features: [
      "Veritabanı Optimizasyonu",
      "Veri Migrasyonu",
      "Yedekleme Çözümleri",
      "Performans İyileştirme",
    ],
  },
  {
    icon: Cloud,
    title: "Cloud Hizmetleri",
    description: "Cloud altyapı ve DevOps çözümleri",
    features: [
      "AWS/Azure Çözümleri",
      "Konteyner Teknolojileri",
      "CI/CD Pipeline",
      "Monitoring",
    ],
  },
  {
    icon: LineChart,
    title: "Danışmanlık",
    description: "Teknoloji danışmanlığı hizmetleri",
    features: [
      "Dijital Dönüşüm",
      "Proje Yönetimi",
      "Teknoloji Seçimi",
      "Risk Analizi",
    ],
  },
];

export default Services;
