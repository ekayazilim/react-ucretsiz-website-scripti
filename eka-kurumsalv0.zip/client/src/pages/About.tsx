import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const About = () => {
  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-6">Hakkımızda</h1>
            <p className="text-xl text-muted-foreground mb-8">
              EKA Yazılım olarak, işletmelerin dijital dönüşümüne öncülük ediyoruz
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1557426272-fc759fdf7a8d"
                alt="Ekip çalışması"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">Vizyonumuz</h2>
              <p className="text-lg text-muted-foreground mb-6">
                Teknoloji dünyasında öncü bir yazılım firması olarak, müşterilerimizin
                ihtiyaçlarını en iyi şekilde anlıyor ve onlara özel çözümler üretiyoruz.
              </p>
              <Link href="/contact">
                <Button>Bize Ulaşın</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Değerlerimiz</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="font-semibold mr-2">İnovasyon:</span>
                  <span className="text-muted-foreground">
                    Sürekli gelişim ve yenilikçi çözümler
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="font-semibold mr-2">Kalite:</span>
                  <span className="text-muted-foreground">
                    En yüksek standartlarda hizmet
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="font-semibold mr-2">Güven:</span>
                  <span className="text-muted-foreground">
                    Müşteri memnuniyeti odaklı yaklaşım
                  </span>
                </li>
              </ul>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f"
                alt="Ekip toplantısı"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
