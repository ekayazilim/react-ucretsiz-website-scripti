import Hero3D from "@/components/Hero3D";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Check, ArrowRight } from "lucide-react";

const Home = () => {
  return (
    <>
      <Hero3D />
      
      <section className="py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            Neden Biz?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-6 bg-background rounded-lg border hover:shadow-lg transition-shadow"
              >
                <feature.icon className="w-12 h-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">
              İşinizi Geleceğe Taşıyalım
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Modern teknolojiler ve yenilikçi çözümlerle işletmenizi bir adım öne çıkarın
            </p>
            <Link href="/contact">
              <Button size="lg">
                Bizimle İletişime Geçin
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

const features = [
  {
    icon: Check,
    title: "Modern Teknolojiler",
    description: "En son teknolojileri kullanarak yenilikçi çözümler üretiyoruz.",
  },
  {
    icon: Check,
    title: "Uzman Ekip",
    description: "Deneyimli ekibimizle projelerinizi profesyonelce yönetiyoruz.",
  },
  {
    icon: Check,
    title: "Özel Çözümler",
    description: "İşletmenizin ihtiyaçlarına özel yazılım çözümleri sunuyoruz.",
  },
];

export default Home;
